const mongoose = require("mongoose");
// const { ObjectId } = mongoose.Schema;
const reviewSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    rating: {
      type: Number,
      required: true,
    },
    comment: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

// const Schema = mongoose.Schema;

// const productSchema = new Schema({
//   title: { type: String, required: true },
//   subject: { type: String, required: true }
// });

module.exports = mongoose.model("Review", reviewSchema);

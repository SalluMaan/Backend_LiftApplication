const Product = require("../models/product");
const formidable = require("formidable");
const fs = require("fs");
const _ = require("lodash");

// exports.getPosts = (req, res) => {
//   const posts = Post.find()
//     .populate("postedBy", "_id name")
//     .select("_id title body")
//     .then((posts) =>
//       res.json({
//         posts,
//       })
//     )
//     .catch((e) =>
//       res.status(400).json({
//         error: e,
//       })
//     );

//   // const {v1 : uuidv1} = require('uuid');
//   // console.log("ID:",uuidv1())
// };

exports.addProduct = (req, res) => {
  const Product = new Product(req.body);
  Product.user = req.profile;
  console.log("ADD Product:", Product);
  Product.save((err, result) => {
    if (err) {
      return res.status(400).json({
        error: err,
      });
    }
    res.json(result);
  });
};

exports.createPost = (req, res) => {
  const post = new Post(req.body);
  post.postedBy = req.profile;
  console.log("CREATE POST:", post);

  // console.log("REQ PROF", req.profile);
  // if (files.photo) {
  //   post.photo.data = fs.readFileSync(files.photo.path);
  //   post.photo.contenType = files.photo.type;
  // }
  post.save((err, result) => {
    if (err) {
      return res.status(400).json({
        error: err,
      });
    }
    res.json(result);
  });
  // let form = new formidable.IncomingForm();
  // form.keepExtensions = true;
  // form.parse(req, (err, fields, files) => {
  //   if (err) {
  //     return res.status(400).json({
  //       error: "Image coudn't be uploaded.",
  //     });
  //   }
  //   let post = new Post(fields);
  //   post.postedBy = req.profile;
  //   // console.log("REQ PROF", req.profile);
  //   if (files.photo) {
  //     post.photo.data = fs.readFileSync(files.photo.path);
  //     post.photo.contenType = files.photo.type;
  //   }
  //   post.save((err, result) => {
  //     if (err) {
  //       return res.status(400).json({
  //         error: err,
  //       });
  //     }
  //     res.json(result);
  //   });
  // }
  // );
  //   const post = new Post(req.body);
  //   console.log("CREATE POST:", post);

  //   post.save().then((d) => res.status(200).json({ post: d }));

  // .catch(e => res.status(400).json({
  //                 error:e
  //             }));

  // post.save((err,result)=>{
  //     if (err) {
  //         return res.status(400).json({
  //             error:err
  //         })
  //     }
  //     res.status(200).json({
  //         post:result
  //     })
  // })
};

// exports.postById = (req, res, next, id) => {
//   Post.findById(id)
//     .populate("postedBy", "_id name")
//     .exec((err, post) => {
//       if (err || !post) {
//         return res.status(400).json({
//           error: "Post not Found",
//         });
//       }

//       req.post = post;
//       next();
//     });
// };

// exports.getPostByID = (req, res) => {
//   return res.json(req.post);
// };

// exports.postByUsers = (req, res) => {
//   Post.find({ postedBy: req.profile._id })
//     .populate("postedBy", "_id name")
//     .sort("_created")
//     .exec((err, post) => {
//       if (err) {
//         return res.status(400).json({
//           error: err,
//         });
//       }
//       res.json(post);
//     });
// };

// exports.isPoster = (req, res, next) => {
//   let postBy = req.post.postedBy._id;
//   const isPoster =
//     req.post &&
//     req.auth &&
//     toString(req.post.postedBy._id) === toString(req.auth._id);
//   console.log("isPOster:", isPoster);
//   // console.log("POST", req.post);
//   // console.log("POST BY", req.post.postedBy._id);
//   // console.log("AUTH", req.auth._id);
//   // console.log(
//   //   "Check:",
//   //   toString(req.post.postedBy._id) === toString(req.auth._id)
//   // );
//   if (!isPoster) {
//     return res.status(403).json({
//       error: "POST:User is not Authorized to perform this Action.",
//     });
//   }
//   next();
// };
// exports.deletePost = (req, res) => {
//   let post = req.post;
//   post.remove((err, post) => {
//     if (err) {
//       return res.status(400).json({
//         error: err,
//       });
//     }
//     res.json({ message: "Post has been deleted Successfully!" });
//   });
// };

// exports.updatePost = (req, res, next) => {
//   let post = req.post;
//   post = _.extend(post, req.body);
//   post.updated = Date.now();
//   post.save((err) => {
//     if (err) {
//       return res.status(400).json({
//         error: "User is not Authorized to perform this Action.",
//       });
//     }
//     res.json(post);
//   });
// };

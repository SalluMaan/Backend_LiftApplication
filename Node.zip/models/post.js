const mongoose = require("mongoose");
const { ObjectId } = mongoose.Schema;
const postSchema = new mongoose.Schema({
  title: {
    type: String,
    required: "Title is required",
    minlength: 4,
    maxlength: 150,
  },
  body: {
    type: String,
    required: "Body is required",
    minlength: 4,
    maxlength: 2000,
  },
  photo: {
    data: Buffer,
    contenType: String,
  },
  postedBy: {
    type: ObjectId,
    ref: "User",
  },
  create: {
    type: Date,
    default: Date.now,
  },
});

// const Schema = mongoose.Schema;

// const postSchema = new Schema({
//   title: { type: String, required: true },
//   subject: { type: String, required: true }
// });

module.exports = mongoose.model("Post", postSchema);

const express = require("express");
const postController = require("../controllers/post");
const validator = require("../validator");
const {
  signup,
  signin,
  signout,
  requireSignin,
} = require("../controllers/auth");
const { userById } = require("../controllers/user");

// const Post =require("../models/post")

const router = express.Router();
router.get("/", requireSignin, postController.getPosts);
// router.get("/", postController.getPosts);
router.get("/posts/by/:userId", requireSignin, postController.postByUsers);
router.get("/post/:postId", postController.getPostByID);

// router.get("/", postController.getPosts);
router.delete(
  "/post/:postId",
  requireSignin,
  postController.isPoster,
  postController.deletePost
);
router.post(
  "/post/new/:userId",
  requireSignin,
  postController.createPost,
  validator.createPostValidator
);

router.put(
  "/post/:postId",
  requireSignin,
  postController.isPoster,
  postController.updatePost
);

//any route contain userID app first exec() userById
router.param("userId", userById);

//any route contain userID app first exec() userById
router.param("postId", postController.postById);

module.exports = router;

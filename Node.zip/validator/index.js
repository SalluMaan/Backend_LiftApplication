exports.createPostValidator = (req, res, next) => {
  req.check("title", "Write a title").notEmpty();
  req
    .check(
      "title",
      "Title must be greater than 4 charcter and max is 150 chracter"
    )
    .isLength({
      min: 4,
      max: 150,
    });
  req.check("body", "Write a body").notEmpty();
  req
    .check(
      "body",
      "Body must be greater than 4 charcter and max is 150 chracter"
    )
    .isLength({
      min: 4,
      max: 200,
    });

  //check for errors
  const errors = req.validationErrors();
  if (errors) {
    const firstError = errors.map((error) => error.msg)[0];
    // console.log("ERROR 1st:".firstError)
    return res.status(400).json({ error: firstError });
  }

  //proceed to next middleware
  next();
};

exports.userSignUpValidator = (req, res, next) => {
  req.check("name", "Its Required.Write a Name").notEmpty();

  req
    .check("email", "Email must be 3 to 32 chracters.")
    .matches(/.+\@.+\..+/)
    .withMessage("Email must contain @.")
    .isLength({
      min: 4,
      max: 2000,
    });

  req.check("password", "Its Required.Write a Password").notEmpty();

  req
    .check(
      "password",
      "Password must be greater than 6 charcter and max is 10 chracter."
    )
    .isLength({ min: 6 })
    .withMessage("Password must contain at least 6 charcter.")
    .matches(/\d/)
    .withMessage("Password must contain a number.");

  //check for errors
  const errors = req.validationErrors();
  if (errors) {
    const firstError = errors.map((error) => error.msg)[0];
    // console.log("ERROR 1st:".firstError)
    return res.status(400).json({ error: firstError });
  }

  //proceed to next middleware
  next();
};

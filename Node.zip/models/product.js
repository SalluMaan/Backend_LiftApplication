const mongoose = require("mongoose");
// const { ObjectId } = mongoose.Schema;
const Review = require("../models/review");

const productSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: "User",
  },
  name: {
    type: String,
    required: "Name is required",
    minlength: 4,
    maxlength: 150,
  },
  image: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
    default: 0,
  },
  description: {
    type: String,
    required: "description is required",
    minlength: 4,
    maxlength: 2000,
  },
  category: {
    type: String,
    required: "category is required",
    minlength: 4,
    maxlength: 150,
  },
  reviews: [Review],
  rating: {
    type: Number,
    required: true,
    default: 0,
  },
  numReviews: {
    type: Number,
    required: true,
    default: 0,
  },
  Stock: {
    type: Number,
    required: true,
    default: 0,
  },
  create: {
    type: Date,
    default: Date.now,
  },
});

// const Schema = mongoose.Schema;

// const productSchema = new Schema({
//   title: { type: String, required: true },
//   subject: { type: String, required: true }
// });

module.exports = mongoose.model("Product", productSchema);
